package de.mrjulsen.paw.compat.sodium.fabric;

import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import me.jellysquid.mods.sodium.client.render.chunk.compile.ChunkBuildBuffers;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.material.DefaultMaterials;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.BlockAndTintGetter;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import de.mrjulsen.paw.fabric.compat.sodium.MeshAppender;
import de.mrjulsen.paw.fabric.compat.sodium.SinkingVertexBuilder;
import de.mrjulsen.paw.fabric.compat.sodium.SodiumCompatEvent;

/**
 * Ported fix for Embeddium
 */
public class MeshAppenderRendererImpl {
    private static final Vector3fc ZERO = new Vector3f();

    private static final ThreadLocal<Reference2ReferenceOpenHashMap<RenderType, SinkingVertexBuilder>> BUILDERS = ThreadLocal.withInitial(() -> {
        Reference2ReferenceOpenHashMap<RenderType, SinkingVertexBuilder> map = new Reference2ReferenceOpenHashMap<>();
        for(RenderType layer : RenderType.chunkBufferLayers()) {
            map.put(layer, new SinkingVertexBuilder());
        }
        return map;
    });

    public static void renderMeshAppenders(BlockAndTintGetter world, SectionPos origin, ChunkBuildBuffers buffers) {
        Reference2ReferenceOpenHashMap<RenderType, SinkingVertexBuilder> builders = BUILDERS.get();

        for (var it = builders.reference2ReferenceEntrySet().fastIterator(); it.hasNext(); ) {
            var entry = it.next();

            entry.getValue().reset();
        }

        MeshAppender.Context context = new MeshAppender.Context(builders::get, world, origin, buffers);
        SodiumCompatEvent.CHUNK_MESHING_EVENT.invoker().render(context);

        for (var it = builders.reference2ReferenceEntrySet().fastIterator(); it.hasNext(); ) {
            var entry = it.next();
            var material = DefaultMaterials.forRenderLayer(entry.getKey());

            entry.getValue().flush(buffers.get(material), material, ZERO);
        }
    }
}