package de.mrjulsen.paw.forge.client.model.loaders;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.math.Axis;
import com.mojang.math.Transformation;

import joptsimple.internal.Strings;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.model.IModelBuilder;
import net.minecraftforge.client.model.geometry.IGeometryBakingContext;
import net.minecraftforge.client.model.geometry.SimpleUnbakedGeometry;
import net.minecraftforge.client.model.geometry.UnbakedGeometryHelper;
import net.minecraftforge.client.model.obj.ObjLoader;
import net.minecraftforge.client.model.obj.ObjMaterialLibrary;
import net.minecraftforge.client.model.obj.ObjTokenizer;
import net.minecraftforge.client.model.pipeline.QuadBakingVertexConsumer;
import net.minecraftforge.client.model.renderable.CompositeRenderable;
import net.minecraftforge.client.textures.UnitTextureAtlasSprite;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A model loaded from an OBJ file.
 * <p>
 * Supports positions, texture coordinates, normals and colors. The
 * {@link ObjMaterialLibrary material library}
 * has support for numerous features, including support for
 * {@link ResourceLocation} textures (non-standard).
 */
public class MultipartObjModel extends SimpleUnbakedGeometry<MultipartObjModel> {
    private static final Vector4f COLOR_WHITE = new Vector4f(1, 1, 1, 1);
    private static final Vec2[] DEFAULT_COORDS = {
            new Vec2(0, 0),
            new Vec2(0, 1),
            new Vec2(1, 1),
            new Vec2(1, 0),
    };

    private final Map<String, ModelGroup> parts = Maps.newLinkedHashMap();
    private final Set<String> rootComponentNames = Collections.unmodifiableSet(parts.keySet());
    private Set<String> allComponentNames;

    private final List<Vector3f> positions = Lists.newArrayList();
    private final List<Vec2> texCoords = Lists.newArrayList();
    private final List<Vector3f> normals = Lists.newArrayList();
    private final List<Vector4f> colors = Lists.newArrayList();

    public final boolean automaticCulling;
    public final boolean shadeQuads;
    public final boolean flipV;
    public final boolean emissiveAmbient;
    @Nullable
    public final String mtlOverride;

    public final ResourceLocation modelLocation;

    private MultipartObjModel(ModelSettings settings) {
        this.modelLocation = settings.modelLocation;
        this.automaticCulling = settings.automaticCulling;
        this.shadeQuads = settings.shadeQuads;
        this.flipV = settings.flipV;
        this.emissiveAmbient = settings.emissiveAmbient;
        this.mtlOverride = settings.mtlOverride;
    }

    public void addPart(String name, ModelGroup part) {
        parts.computeIfAbsent(name, a -> part);
    }
    
    public Collection<? extends ModelObject> getParts() {
        return parts.values();
    }

    public static MultipartObjModel parse(ObjTokenizer tokenizer, ModelSettings settings) throws IOException {
        var modelLocation = settings.modelLocation;
        var materialLibraryOverrideLocation = settings.mtlOverride;
        var model = new MultipartObjModel(settings);

        // for relative references to material libraries
        String modelDomain = modelLocation.getNamespace();
        String modelPath = modelLocation.getPath();
        int lastSlash = modelPath.lastIndexOf('/');
        if (lastSlash >= 0)
            modelPath = modelPath.substring(0, lastSlash + 1); // include the '/'
        else
            modelPath = "";

        ObjMaterialLibrary mtllib = ObjMaterialLibrary.EMPTY;
        ObjMaterialLibrary.Material currentMat = null;
        String currentSmoothingGroup = null;
        ModelGroup currentGroup = null;
        ModelObject currentObject = null;
        ModelMesh currentMesh = null;

        boolean objAboveGroup = false;

        if (materialLibraryOverrideLocation != null) {
            String lib = materialLibraryOverrideLocation;
            if (lib.contains(":"))
                mtllib = ObjLoader.INSTANCE.loadMaterialLibrary(new ResourceLocation(lib));
            else
                mtllib = ObjLoader.INSTANCE.loadMaterialLibrary(new ResourceLocation(modelDomain, modelPath + lib));
        }

        String[] line;
        while ((line = tokenizer.readAndSplitLine(true)) != null) {
            switch (line[0]) {
                case "mtllib": // Loads material library
                {
                    if (materialLibraryOverrideLocation != null)
                        break;

                    String lib = line[1];
                    if (lib.contains(":"))
                        mtllib = ObjLoader.INSTANCE.loadMaterialLibrary(new ResourceLocation(lib));
                    else
                        mtllib = ObjLoader.INSTANCE
                                .loadMaterialLibrary(new ResourceLocation(modelDomain, modelPath + lib));
                    break;
                }

                case "usemtl": // Sets the current material (starts new mesh)
                {
                    String mat = Strings.join(Arrays.copyOfRange(line, 1, line.length), " ");
                    ObjMaterialLibrary.Material newMat = mtllib.getMaterial(mat);
                    if (!Objects.equals(newMat, currentMat)) {
                        currentMat = newMat;
                        if (currentMesh != null && currentMesh.mat == null && currentMesh.faces.size() == 0) {
                            currentMesh.mat = currentMat;
                        } else {
                            // Start new mesh
                            currentMesh = null;
                        }
                    }
                    break;
                }

                case "v": // Vertex
                    model.positions.add(parseVector4To3(line));
                    break;
                case "vt": // Vertex texcoord
                    model.texCoords.add(parseVector2(line));
                    break;
                case "vn": // Vertex normal
                    model.normals.add(parseVector3(line));
                    break;
                case "vc": // Vertex color (non-standard)
                    model.colors.add(parseVector4(line));
                    break;

                case "f": // Face
                {
                    if (currentMesh == null) {
                        currentMesh = model.new ModelMesh(null, currentMat, currentSmoothingGroup);
                        if (currentObject != null) {
                            currentObject.meshes.add(currentMesh);
                        } else {
                            if (currentGroup == null) {
                                currentGroup = model.new ModelGroup("", new SubModelSettings());
                                model.parts.put("", currentGroup);
                            }
                            currentGroup.meshes.add(currentMesh);
                        }
                    }

                    int[][] vertices = new int[line.length - 1][];
                    for (int i = 0; i < vertices.length; i++) {
                        String vertexData = line[i + 1];
                        String[] vertexParts = vertexData.split("/");
                        int[] vertex = Arrays.stream(vertexParts)
                                .mapToInt(num -> Strings.isNullOrEmpty(num) ? 0 : Integer.parseInt(num)).toArray();
                        if (vertex[0] < 0)
                            vertex[0] = model.positions.size() + vertex[0];
                        else
                            vertex[0]--;
                        if (vertex.length > 1) {
                            if (vertex[1] < 0)
                                vertex[1] = model.texCoords.size() + vertex[1];
                            else
                                vertex[1]--;
                            if (vertex.length > 2) {
                                if (vertex[2] < 0)
                                    vertex[2] = model.normals.size() + vertex[2];
                                else
                                    vertex[2]--;
                                if (vertex.length > 3) {
                                    if (vertex[3] < 0)
                                        vertex[3] = model.colors.size() + vertex[3];
                                    else
                                        vertex[3]--;
                                }
                            }
                        }
                        vertices[i] = vertex;
                    }

                    currentMesh.faces.add(vertices);

                    break;
                }

                case "s": // Smoothing group (starts new mesh)
                {
                    String smoothingGroup = "off".equals(line[1]) ? null : line[1];
                    if (!Objects.equals(currentSmoothingGroup, smoothingGroup)) {
                        currentSmoothingGroup = smoothingGroup;
                        if (currentMesh != null && currentMesh.smoothingGroup == null
                                && currentMesh.faces.size() == 0) {
                            currentMesh.smoothingGroup = currentSmoothingGroup;
                        } else {
                            // Start new mesh
                            currentMesh = null;
                        }
                    }
                    break;
                }

                case "g": {
                    String name = line[1];
                    if (objAboveGroup) {
                        currentObject = model.new ModelObject(currentGroup.name() + "/" + name, new SubModelSettings());
                        currentGroup.parts.put(name, currentObject);
                    } else {
                        currentGroup = model.new ModelGroup(name, new SubModelSettings());
                        model.parts.put(name, currentGroup);
                        currentObject = null;
                    }
                    // Start new mesh
                    currentMesh = null;
                    break;
                }

                case "o": {
                    String name = line[1];
                    if (objAboveGroup || currentGroup == null) {
                        objAboveGroup = true;

                        currentGroup = model.new ModelGroup(name, new SubModelSettings());
                        model.parts.put(name, currentGroup);
                        currentObject = null;
                    } else {
                        currentObject = model.new ModelObject(currentGroup.name() + "/" + name, new SubModelSettings());
                        currentGroup.parts.put(name, currentObject);
                    }
                    // Start new mesh
                    currentMesh = null;
                    break;
                }
            }
        }
        return model;
    }

    private static Vector3f parseVector4To3(String[] line) {
        Vector4f vec4 = parseVector4(line);
        return new Vector3f(
                vec4.x() / vec4.w(),
                vec4.y() / vec4.w(),
                vec4.z() / vec4.w());
    }

    private static Vec2 parseVector2(String[] line) {
        return switch (line.length) {
            case 1 -> new Vec2(0, 0);
            case 2 -> new Vec2(Float.parseFloat(line[1]), 0);
            default -> new Vec2(Float.parseFloat(line[1]), Float.parseFloat(line[2]));
        };
    }

    private static Vector3f parseVector3(String[] line) {
        return switch (line.length) {
            case 1 -> new Vector3f();
            case 2 -> new Vector3f(Float.parseFloat(line[1]), 0, 0);
            case 3 -> new Vector3f(Float.parseFloat(line[1]), Float.parseFloat(line[2]), 0);
            default -> new Vector3f(Float.parseFloat(line[1]), Float.parseFloat(line[2]), Float.parseFloat(line[3]));
        };
    }

    static Vector4f parseVector4(String[] line) {
        return switch (line.length) {
            case 1 -> new Vector4f();
            case 2 -> new Vector4f(Float.parseFloat(line[1]), 0, 0, 1);
            case 3 -> new Vector4f(Float.parseFloat(line[1]), Float.parseFloat(line[2]), 0, 1);
            case 4 -> new Vector4f(Float.parseFloat(line[1]), Float.parseFloat(line[2]), Float.parseFloat(line[3]), 1);
            default -> new Vector4f(Float.parseFloat(line[1]), Float.parseFloat(line[2]), Float.parseFloat(line[3]),
                    Float.parseFloat(line[4]));
        };
    }

    @Override
    protected void addQuads(IGeometryBakingContext owner, IModelBuilder<?> modelBuilder, ModelBaker baker,
            Function<Material, TextureAtlasSprite> spriteGetter, ModelState modelTransform,
            ResourceLocation modelLocation) {
        parts.values().stream().filter(part -> owner.isComponentVisible(part.name(), true))
                .forEach(
                        part -> part.addQuads(owner, modelBuilder, baker, spriteGetter, modelTransform, modelLocation));
    }

    public Set<String> getRootComponentNames() {
        return rootComponentNames;
    }

    @Override
    public Set<String> getConfigurableComponentNames() {
        if (allComponentNames != null)
            return allComponentNames;
        var names = new HashSet<String>();
        for (var group : parts.values())
            group.addNamesRecursively(names);
        return allComponentNames = Collections.unmodifiableSet(names);
    }

    private Pair<BakedQuad, Direction> makeQuad(SubModelSettings subSettings, int[][] indices, int tintIndex, Vector4f colorTint,
            Vector4f ambientColor, TextureAtlasSprite texture, Transformation transform) {
        boolean needsNormalRecalculation = false;
        for (int[] ints : indices) {
            needsNormalRecalculation |= ints.length < 3;
        }
        Vector3f faceNormal = new Vector3f();
        if (needsNormalRecalculation) {
            Vector3f a = positions.get(indices[0][0]);
            Vector3f ab = positions.get(indices[1][0]);
            Vector3f ac = positions.get(indices[2][0]);
            Vector3f abs = new Vector3f(ab);
            abs.sub(a);
            Vector3f acs = new Vector3f(ac);
            acs.sub(a);
            abs.cross(acs);
            abs.normalize();
            faceNormal = abs;
        }

        var quadBaker = new QuadBakingVertexConsumer.Buffered();

        quadBaker.setSprite(texture);
        quadBaker.setTintIndex(tintIndex);

        int uv2 = 0;
        if (emissiveAmbient) {
            int fakeLight = (int) ((ambientColor.x() + ambientColor.y() + ambientColor.z()) * 15 / 3.0f);
            uv2 = LightTexture.pack(fakeLight, fakeLight);
            quadBaker.setShade(fakeLight == 0 && shadeQuads);
        } else {
            quadBaker.setShade(shadeQuads);
        }

        boolean hasTransform = !transform.isIdentity();
        // The incoming transform is referenced on the center of the block, but our
        // coords are referenced on the corner
        Transformation transformation = hasTransform ? transform.blockCenterToCorner() : transform;

        if (subSettings != null) {
            Vector3f eulerRadians = transformation.getLeftRotation().getEulerAnglesYXZ(new Vector3f());
            Vector3f oldRot = new Vector3f(
                (float) Math.toDegrees(eulerRadians.x),
                (float) Math.toDegrees(eulerRadians.y),
                (float) Math.toDegrees(eulerRadians.z)
            );
            Vector3f rot = new Vector3f(subSettings.rotX(), subSettings.rotY(), subSettings.rotZ());
            Vec3 offset = new Vec3(subSettings.x() / 16f, subSettings.y() / 16f, subSettings.z() / 16f);
            offset = VecHelper.rotateCentered(offset, oldRot.x(), net.minecraft.core.Direction.Axis.X);
            offset = VecHelper.rotateCentered(offset, oldRot.y(), net.minecraft.core.Direction.Axis.Y);
            offset = VecHelper.rotateCentered(offset, oldRot.z(), net.minecraft.core.Direction.Axis.Z);
            Quaternionf q = Axis.YP.rotationDegrees((float)(rot.y() + oldRot.y()));
            q.mul(Axis.XP.rotationDegrees((float)(rot.x() + oldRot.x())));
            q.mul(Axis.ZP.rotationDegrees((float)(rot.z() + oldRot.z())));
            transformation = new Transformation(new Vector3f((float)offset.x(), (float)offset.y(), (float)offset.z()), q, transformation.getScale(), transformation.getRightRotation());
            hasTransform = true;
        }

        Vector4f[] pos = new Vector4f[4];
        Vector3f[] norm = new Vector3f[4];

        for (int i = 0; i < 4; i++) {
            int[] index = indices[Math.min(i, indices.length - 1)];
            Vector4f position = new Vector4f(positions.get(index[0]), 1);
            Vec2 texCoord = index.length >= 2 && texCoords.size() > 0 ? texCoords.get(index[1]) : DEFAULT_COORDS[i];
            Vector3f norm0 = !needsNormalRecalculation && index.length >= 3 && normals.size() > 0
                    ? normals.get(index[2])
                    : faceNormal;
            Vector3f normal = norm0;
            Vector4f color = index.length >= 4 && colors.size() > 0 ? colors.get(index[3]) : COLOR_WHITE;
            if (hasTransform) {
                normal = new Vector3f(norm0);
                transformation.transformPosition(position);
                transformation.transformNormal(normal);
            }
            Vector4f tintedColor = new Vector4f(
                    color.x() * colorTint.x(),
                    color.y() * colorTint.y(),
                    color.z() * colorTint.z(),
                    color.w() * colorTint.w());
            quadBaker.vertex(position.x(), position.y(), position.z());
            quadBaker.color(tintedColor.x(), tintedColor.y(), tintedColor.z(), tintedColor.w());
            quadBaker.uv(
                    texture.getU(texCoord.x * 16),
                    texture.getV((flipV ? 1 - texCoord.y : texCoord.y) * 16));
            quadBaker.uv2(uv2);
            quadBaker.normal(normal.x(), normal.y(), normal.z());
            if (i == 0) {
                quadBaker.setDirection(Direction.getNearest(normal.x(), normal.y(), normal.z()));
            }
            quadBaker.endVertex();
            pos[i] = position;
            norm[i] = normal;
        }

        Direction cull = null;
        if (automaticCulling) {
            if (Mth.equal(pos[0].x(), 0) && // vertex.position.x
                    Mth.equal(pos[1].x(), 0) &&
                    Mth.equal(pos[2].x(), 0) &&
                    Mth.equal(pos[3].x(), 0) &&
                    norm[0].x() < 0) // vertex.normal.x
            {
                cull = Direction.WEST;
            } else if (Mth.equal(pos[0].x(), 1) && // vertex.position.x
                    Mth.equal(pos[1].x(), 1) &&
                    Mth.equal(pos[2].x(), 1) &&
                    Mth.equal(pos[3].x(), 1) &&
                    norm[0].x() > 0) // vertex.normal.x
            {
                cull = Direction.EAST;
            } else if (Mth.equal(pos[0].z(), 0) && // vertex.position.z
                    Mth.equal(pos[1].z(), 0) &&
                    Mth.equal(pos[2].z(), 0) &&
                    Mth.equal(pos[3].z(), 0) &&
                    norm[0].z() < 0) // vertex.normal.z
            {
                cull = Direction.NORTH; // can never remember
            } else if (Mth.equal(pos[0].z(), 1) && // vertex.position.z
                    Mth.equal(pos[1].z(), 1) &&
                    Mth.equal(pos[2].z(), 1) &&
                    Mth.equal(pos[3].z(), 1) &&
                    norm[0].z() > 0) // vertex.normal.z
            {
                cull = Direction.SOUTH;
            } else if (Mth.equal(pos[0].y(), 0) && // vertex.position.y
                    Mth.equal(pos[1].y(), 0) &&
                    Mth.equal(pos[2].y(), 0) &&
                    Mth.equal(pos[3].y(), 0) &&
                    norm[0].y() < 0) // vertex.normal.z
            {
                cull = Direction.DOWN; // can never remember
            } else if (Mth.equal(pos[0].y(), 1) && // vertex.position.y
                    Mth.equal(pos[1].y(), 1) &&
                    Mth.equal(pos[2].y(), 1) &&
                    Mth.equal(pos[3].y(), 1) &&
                    norm[0].y() > 0) // vertex.normal.y
            {
                cull = Direction.UP;
            }
        }

        return Pair.of(quadBaker.getQuad(), cull);
    }

    public CompositeRenderable bakeRenderable(IGeometryBakingContext configuration) {
        var builder = CompositeRenderable.builder();

        for (var entry : parts.entrySet()) {
            var name = entry.getKey();
            var part = entry.getValue();
            part.bake(builder.child(name), configuration);
        }

        return builder.get();
    }

    public class ModelObject {
        public final String name;
        final SubModelSettings settings;

        List<ModelMesh> meshes = Lists.newArrayList();

        ModelObject(String name, SubModelSettings settings) {
            this.name = name;
            this.settings = settings;
        }

        public ModelObject copy(SubModelSettings settings) {
            ModelObject m = new ModelObject(name, this.settings.combineTransform(settings));
            m.meshes.addAll(meshes.stream().map(x -> x.copy(this.settings.combineTransform(settings))).toList());
            return m;
        }

        public String name() {
            return name;
        }

        public void addQuads(IGeometryBakingContext owner, IModelBuilder<?> modelBuilder, ModelBaker baker,
                Function<Material, TextureAtlasSprite> spriteGetter, ModelState modelTransform,
                ResourceLocation modelLocation) {

            for (ModelMesh mesh : meshes) {
                mesh.addQuads(owner, modelBuilder, spriteGetter, modelTransform);
            }
        }

        public void bake(CompositeRenderable.PartBuilder<?> builder, IGeometryBakingContext configuration) {
            for (ModelMesh mesh : this.meshes) {
                mesh.bake(builder, configuration);
            }
        }

        public Collection<Material> getTextures(IGeometryBakingContext owner,
                Function<ResourceLocation, UnbakedModel> modelGetter,
                Set<com.mojang.datafixers.util.Pair<String, String>> missingTextureErrors) {

            return meshes.stream()
                    .flatMap(mesh -> mesh.mat != null
                            ? Stream.of(UnbakedGeometryHelper.resolveDirtyMaterial(mesh.mat.diffuseColorMap, owner))
                            : Stream.of())
                    .collect(Collectors.toSet());
        }

        protected void addNamesRecursively(Set<String> names) {
            names.add(name());
        }
    }

    public class ModelGroup extends ModelObject {
        final Map<String, ModelObject> parts = Maps.newLinkedHashMap();

        ModelGroup(String name, SubModelSettings settings) {
            super(name, settings);
        }

        public Collection<? extends ModelObject> getParts() {
            return parts.values();
        }

        public ModelGroup copy(SubModelSettings settings, String name) {
            ModelGroup m = new ModelGroup(name, this.settings.combineTransform(settings));
            m.parts.putAll(parts.entrySet().stream().collect(Collectors.toMap(a -> a.getKey(), a -> a.getValue().copy(a.getValue().settings.combineTransform(settings)))));
            m.meshes.addAll(meshes.stream().map(x -> x.copy(settings.combineTransform(x.subSettings))).toList());
            return m;
        }

        @Override
        public void addQuads(IGeometryBakingContext owner, IModelBuilder<?> modelBuilder, ModelBaker baker,
                Function<Material, TextureAtlasSprite> spriteGetter, ModelState modelTransform,
                ResourceLocation modelLocation) {
            super.addQuads(owner, modelBuilder, baker, spriteGetter, modelTransform, modelLocation);

            getParts().stream().filter(part -> owner.isComponentVisible(part.name(), true))
                    .forEach(part -> part.addQuads(owner, modelBuilder, baker, spriteGetter, modelTransform,
                            modelLocation));
        }

        @Override
        public void bake(CompositeRenderable.PartBuilder<?> builder, IGeometryBakingContext configuration) {
            super.bake(builder, configuration);

            for (var entry : parts.entrySet()) {
                var name = entry.getKey();
                var part = entry.getValue();
                part.bake(builder.child(name), configuration);
            }
        }

        @Override
        public Collection<Material> getTextures(IGeometryBakingContext owner,
                Function<ResourceLocation, UnbakedModel> modelGetter,
                Set<com.mojang.datafixers.util.Pair<String, String>> missingTextureErrors) {
            Set<Material> combined = Sets.newHashSet();
            combined.addAll(super.getTextures(owner, modelGetter, missingTextureErrors));
            for (ModelObject part : parts.values())
                combined.addAll(part.getTextures(owner, modelGetter, missingTextureErrors));
            return combined;
        }

        @Override
        protected void addNamesRecursively(Set<String> names) {
            super.addNamesRecursively(names);
            for (ModelObject object : parts.values())
                object.addNamesRecursively(names);
        }
    }

    private class ModelMesh {
        @Nullable
        public ObjMaterialLibrary.Material mat;
        @Nullable
        public String smoothingGroup;
        public final List<int[][]> faces = Lists.newArrayList();
        public SubModelSettings subSettings;

        public ModelMesh(SubModelSettings subSettings, @Nullable ObjMaterialLibrary.Material currentMat, @Nullable String currentSmoothingGroup) {
            this.mat = currentMat;
            this.smoothingGroup = currentSmoothingGroup;
            this.subSettings = subSettings;
        }

        public ModelMesh copy(SubModelSettings subSettings) {
            ModelMesh m = new ModelMesh(subSettings, mat, smoothingGroup);
            m.faces.addAll(faces);
            return m;
        }

        public void addQuads(IGeometryBakingContext owner, IModelBuilder<?> modelBuilder,
                Function<Material, TextureAtlasSprite> spriteGetter, ModelState modelTransform) {
            if (mat == null)
                return;
            TextureAtlasSprite texture = spriteGetter
                    .apply(UnbakedGeometryHelper.resolveDirtyMaterial(mat.diffuseColorMap, owner));
            int tintIndex = mat.diffuseTintIndex;
            Vector4f colorTint = mat.diffuseColor;

            var rootTransform = owner.getRootTransform();
            var transform = rootTransform.isIdentity() ? modelTransform.getRotation()
                    : modelTransform.getRotation().compose(rootTransform);
            for (int[][] face : faces) {
                Pair<BakedQuad, Direction> quad = makeQuad(subSettings, face, tintIndex, colorTint, mat.ambientColor, texture,
                        transform);
                if (quad.getRight() == null)
                    modelBuilder.addUnculledFace(quad.getLeft());
                else
                    modelBuilder.addCulledFace(quad.getRight(), quad.getLeft());
            }
        }

        public void bake(CompositeRenderable.PartBuilder<?> builder, IGeometryBakingContext configuration) {
            ObjMaterialLibrary.Material mat = this.mat;
            if (mat == null)
                return;
            int tintIndex = mat.diffuseTintIndex;
            Vector4f colorTint = mat.diffuseColor;

            final List<BakedQuad> quads = new ArrayList<>();

            for (var face : this.faces) {
                var pair = makeQuad(subSettings, face, tintIndex, colorTint, mat.ambientColor, UnitTextureAtlasSprite.INSTANCE,
                        Transformation.identity());
                quads.add(pair.getLeft());
            }

            ResourceLocation textureLocation = UnbakedGeometryHelper
                    .resolveDirtyMaterial(mat.diffuseColorMap, configuration).texture();
            ResourceLocation texturePath = new ResourceLocation(textureLocation.getNamespace(),
                    "textures/" + textureLocation.getPath() + ".png");

            builder.addMesh(texturePath, quads);
        }
    }

    public record ModelSettings(@NotNull ResourceLocation modelLocation,
            boolean automaticCulling, boolean shadeQuads, boolean flipV,
            boolean emissiveAmbient, @Nullable String mtlOverride,
            List<SubModelSettings> subSettings) {
    }

    public static class SubModelSettings {
        String model;
        float[] offset = new float[3];
        float[] rotation = new float[3];
        boolean centered = false;
        boolean inheritable = true;

        public SubModelSettings() {}

        public SubModelSettings(String model, float[] offset, float[] rotation, boolean centered, boolean inheritable) {
            this.model = model;
            this.offset = offset;
            this.rotation = rotation;
            this.centered = centered;
            this.inheritable = inheritable;
        }

        public String model() {
            return model;
        }

        public float x() {
            return offset[0] - (centered ? 8 : 0);
        }

        public float y() {
            return offset[1] - (centered ? 8 : 0);
        }

        public float z() {
            return offset[2] - (centered ? 8 : 0);
        }

        public float rotX() {
            return rotation[0];
        }

        public float rotY() {
            return rotation[1];
        }

        public float rotZ() {
            return rotation[2];
        }

        public boolean centered() {
            return centered;
        }

        public boolean isJson() {
            return model.endsWith(".json");
        }

        public boolean inheritable() {
            return inheritable;
        }

        public SubModelSettings combineTransform(@Nullable SubModelSettings other) {
            if (other == null) {
                return new SubModelSettings(
                    model(),
                    new float[] {
                        offset[0],
                        offset[1],
                        offset[2]
                    },
                    new float[] {
                        rotation[0],
                        rotation[1],
                        rotation[2]
                    },
                    centered(),
                    other == null ? inheritable() : other.inheritable()
                );
            }
            return new SubModelSettings(
                model(),
                new float[] {
                    offset[0] + other.offset[0],
                    offset[1] + other.offset[1],
                    offset[2] + other.offset[2]
                },
                new float[] {
                    rotation[0] + other.rotation[0],
                    rotation[1] + other.rotation[1],
                    rotation[2] + other.rotation[2]
                },
                centered(),
                other == null ? inheritable() : other.inheritable()
            );
        }
    }
}
